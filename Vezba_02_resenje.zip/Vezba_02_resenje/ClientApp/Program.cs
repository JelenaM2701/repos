﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Security.Cryptography.X509Certificates;
using Manager;
using Common;

namespace ClientApp
{
	public class Program
	{
		static void Main(string[] args)
		{

            #region prethodniKod

            /// Define the expected service certificate. It is required to establish cmmunication using certificates.
            string srvCertCN = "wcfservice";

            /// Define the expected certificate for signing ("<username>_sign" is the expected subject name).
            /// .NET WindowsIdentity class provides information about Windows user running the given process
            string signCertCN = String.Empty;

            /// Define subjectName for certificate used for signing which is not as expected by the service
            string wrongCertCN = String.Empty;

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            X509Certificate2 srvCert = CertManager.GetCertificateFromStorage(StoreName.TrustedPeople, StoreLocation.LocalMachine, srvCertCN);
            EndpointAddress address = new EndpointAddress(new Uri("net.tcp://localhost:10000/Receiver"),
                                      new X509CertificateEndpointIdentity(srvCert));
             
            try
            {
                #endregion
                using (WCFClientCert proxy = new WCFClientCert(binding, address))
                {

                    int isAuth = proxy.TestCommunication();
                    

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }

            NetTcpBinding binding2 = new NetTcpBinding();
            binding2.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            EndpointAddress address2 = new EndpointAddress(new Uri("net.tcp://localhost:10001/Receiver"));
            using (WCFClient proxy = new WCFClient(binding2, address2))
            {

                while (true)
                {
                    Console.WriteLine(" -- (1): OTVORI RACUN -- ");
                    Console.WriteLine(" -- (2): ZATVORI RACUN -- ");
                    Console.WriteLine(" -- (3): PROVERI STANJE -- ");
                    Console.WriteLine(" -- (4): UPLATA -- ");
                    Console.WriteLine(" -- (5): ISPLATA -- ");
                    Console.WriteLine(" -- (6): OPOMENA -- ");

                    int choice = Int32.Parse(Console.ReadLine());

                    {
                        switch (choice)
                        {
                            case 1:
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.OtvoriRacun(new Korisnik(Console.ReadLine())));
                                break;

                            case 2:
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.ZatvoriRacun(new Korisnik(Console.ReadLine())));
                                break;

                            case 3:
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.ProveriStanje(new Korisnik(Console.ReadLine())));
                                break;

                            case 4:
                                Console.WriteLine("Unesite iznos za uplatu: ");
                                double iznos = Double.Parse(Console.ReadLine());
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.Uplata(new Korisnik(Console.ReadLine()), iznos));
                                break;

                            case 5:
                                Console.WriteLine("Unesite iznos za isplatu: ");
                                double iznos2 = Double.Parse(Console.ReadLine());
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.Isplata(new Korisnik(Console.ReadLine()), iznos2));
                                break;

                            case 6:
                                Console.WriteLine("Unesite korisnicko ime klijenta: ");
                                Console.WriteLine(proxy.Opomena(new Korisnik(Console.ReadLine())));
                                break;

                            default:
                                Console.WriteLine("Uneli ste pogresnu komandu!\r\n");
                                break;
                        }
                    }
                }
            }
        }

    }
}
