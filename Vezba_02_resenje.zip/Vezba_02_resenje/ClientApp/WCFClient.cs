﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Contracts;
using Manager;
using System.Security.Principal;
using Common;
using System.Security.Cryptography.X509Certificates;

namespace ClientApp
{
	public class WCFClient : ChannelFactory<IWCFContract>, IWCFContract, IDisposable
	{
		IWCFContract factory;

		public WCFClient(NetTcpBinding binding, EndpointAddress address)
			: base(binding, address)
		{
			/// cltCertCN.SubjectName should be set to the client's username. .NET WindowsIdentity class provides information about Windows user running the given process

			factory = this.CreateChannel();
		}

	

		public void SendMessage(string message, byte[] sign)
		{
			try
			{
				factory.SendMessage(message, sign);
			}
			catch (Exception e)
			{
				Console.WriteLine("[SendMessage] ERROR = {0}", e.Message);
			}
		}

		public void Dispose()
		{
			if (factory != null)
			{
				factory = null;
			}

			this.Close();
		}

        public string OtvoriRacun(Korisnik k)
        {
            try
            {
                return factory.OtvoriRacun(k);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to OtvoriRacun. Error message : {0}", e.Message);
            }

            return "";
        }

        public string ZatvoriRacun(Korisnik k)
        {
            try
            {
                return factory.ZatvoriRacun(k);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to ZatvoriRacun. Error message : {0}", e.Message);
            }

            return "";
        }

        public string ProveriStanje(Korisnik k)
        {
            try
            {
                return factory.ProveriStanje(k);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to ProveriStanje. Error message : {0}", e.Message);
            }

            return "";
        }

        public string Uplata(Korisnik k, double suma)
        {
            try
            {
                return factory.Uplata(k, suma);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to Uplata. Error message : {0}", e.Message);
            }

            return "";
        }

        public string Isplata(Korisnik k, double suma)
        {
            try
            {
                return factory.Isplata(k, suma);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to Isplata. Error message : {0}", e.Message);
            }

            return "";
        }

        public string Opomena(Korisnik k)
        {
            try
            {
                return factory.Opomena(k);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error while trying to Opomena. Error message : {0}", e.Message);
            }

            return "";
        }
    }
}
