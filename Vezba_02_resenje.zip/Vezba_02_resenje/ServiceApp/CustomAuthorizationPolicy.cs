﻿using Manager;
using System;
using System.Collections.Generic;
using System.IdentityModel.Claims;
using System.IdentityModel.Policy;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ServiceApp
{
    //hiiiiiii // HELLO
    public class CustomAuthorizationPolicy:IAuthorizationPolicy
    {
        //global unique identifier
        string id = Guid.NewGuid().ToString();

        public string Id
        {
            get { return this.id; }
        }

        public ClaimSet Issuer
        {
            get { return ClaimSet.System; }
        }

        public bool Evaluate(EvaluationContext evaluationContext, ref object state)
        {
            object list = null;

            //pronalaze se informacije o korisniku: identitet .. IIdenTITY wINDOWSIDENTITY 
            if (!evaluationContext.Properties.TryGetValue("Identities", out list))
            {
                return false;
            }

            IList<IIdentity> identities = list as IList<IIdentity>;
            if (list == null || identities.Count <= 0)
            {
                return false;
            }

            IIdentity identityToReturn = identities[0];
            // ovde se podesava da ne bude ugradjeni principal vec onaj koji smo mi napravili
            evaluationContext.Properties["Principal"] = new MyPrincipal(identityToReturn);
            
            return true;
        }
    }
}
