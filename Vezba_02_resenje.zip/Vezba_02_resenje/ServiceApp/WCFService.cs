﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using Manager;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using Common;
using Manager;
using System.ServiceModel;
using System.Diagnostics;

namespace ServiceApp
{
	public class WCFService : IWCFContract
	{
        private Random randomGenerator = new Random();
        TransactionsOperator transactionOperator= new TransactionsOperator();

        public void TestCommunication()
		{
			Console.WriteLine("Communication established.");
		}

		public void SendMessage(string message, byte[] sign)
		{
            /// Get client's certificate from storage. It is expected that clients sign messages using the certificate with subjectName in the following format "<username>_sign" 
            X509Certificate2 clientCertificate = null;

            /// Verify signature using SHA1 hash algorithm
            /// DigitalSignature.Verify();
        }
        
        public string OtvoriRacun(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";
            if (Thread.CurrentPrincipal.IsInRole("OtvoriRacun"))
            {

                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        returnMessage = "Korisnik vec ima racun!\n";
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }
                  
               
                Racun noviRacun = new Racun((long)randomGenerator.Next(100000, 999999), 0, 100, 0, DateTime.Now, k);
                TransactionsOperator.transactions.Add(noviRacun);
                returnMessage = "Racun sa brojem: " + noviRacun.BrojRacuna.ToString() + " je otvoren.\n";
                transactionOperator.UpdateData();
                transactionOperator.ReportTransaction(returnMessage);
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
            }
            else
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }

            return returnMessage;
        }

        public string ZatvoriRacun(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("ZatvoriRacun"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        TransactionsOperator.transactions.Remove(r);
                        returnMessage = "Racun sa brojem: " + r.BrojRacuna.ToString() + " je zatvoren.\n";
                        transactionOperator.UpdateData();
                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
            }
            else
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }

            return returnMessage;
        }

        public string ProveriStanje(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("ProveriStanje"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        returnMessage = "Trenutno stanje na racunu iznosi: " + r.Iznos.ToString() + " dinara.\n";
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }

            return returnMessage;
        }

        public string Uplata(Korisnik k, double suma)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("Uplata"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        r.Iznos += suma;

                        if (r.Iznos >= 0 && r.Blokiran == 1)
                            r.Blokiran = 0;

                        returnMessage = "Uplata je izvrsena.\n";
                        returnMessage = "Uplata na racun: " + r.BrojRacuna.ToString() + " u iznosi od: " + suma.ToString() + " dinara je izvrsena.\n";
                        r.PoslednjaTransakcija = DateTime.Now;
                        transactionOperator.UpdateData();
                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }

            return returnMessage;
        }

        public string Isplata(Korisnik k, double suma)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("Isplata"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        if (r.Blokiran == 1)
                        {
                            returnMessage = "Isplata nije moguca, racun je blokiran!\n";
                            Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                            return returnMessage;
                        }
                        if (r.Iznos - suma < 0)
                        {
                            if (Math.Abs(r.Iznos - suma) > r.DozvoljeniMinus)
                            {
                                returnMessage = "Isplata nije moguca, iznos je veci od dozvoljenog minusa!\n";
                                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                                return returnMessage;
                            }
                        }

                        r.Iznos -= suma;
                        returnMessage = "Isplata sa racuna: " + r.BrojRacuna.ToString() + " u iznosi od: " + suma.ToString() + " dinara je izvrsena.\n";
                        r.PoslednjaTransakcija = DateTime.Now;
                        transactionOperator.UpdateData();
                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }

            return returnMessage;
        }

        public string Opomena(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("Opomena"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        if (r.Iznos < 0)
                        {
                            r.Blokiran = 1;
                            returnMessage = "Racun blokiran. Opomena!\n";
                            transactionOperator.UpdateData();
                            transactionOperator.ReportTransaction(returnMessage);
                            Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                            return returnMessage;
                        }

                        returnMessage = "Iznos na racunu korisnika nije u minusu!\n";
                        Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
            }
            else
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, "TransactionService", returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }

            return returnMessage;
        }
    }
}
