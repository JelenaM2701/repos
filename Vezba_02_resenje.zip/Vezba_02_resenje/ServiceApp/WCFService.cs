﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;
using Manager;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using Common;
using Manager;
using System.ServiceModel;
using System.Diagnostics;

namespace ServiceApp
{
	public class WCFService : IWCFContract
	{        
        TransactionsOperator transactionOperator= new TransactionsOperator();
  
        public string OtvoriRacun(Korisnik k)
        {
            
            //Thread sadrzi informacije vezane za klijenta koji se konektovao na server
            // Thread.Identity bi na primer uzeo Identitet klijenta koji ima ime klijent grupe itd ^^
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal; 
            string returnMessage = "";
            //proverava da .CurrentPrincipalli je u grupi da nismo uradili svoje
            //a sada mi proverava da li se nalazi u grupi koja ima tu permisiju
            if (Thread.CurrentPrincipal.IsInRole("OtvoriRacun"))
            {
                long maxId = 100000; 
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.BrojRacuna > maxId)
                    {
                        maxId = r.BrojRacuna;
                    }
                    if (r.Vlasnik.Username == k.Username)
                    {
                        returnMessage = "Korisnik vec ima racun!\n";
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }
                
                // 100001 100002 100003


                Racun noviRacun = new Racun((long)maxId + 1, 0, 100, 0, DateTime.Now, k);
                TransactionsOperator.transactions.Add(noviRacun);
                returnMessage = "Racun sa brojem: " + noviRacun.BrojRacuna.ToString() + " je otvoren.\n";
                transactionOperator.UpdateData();
                Audit.TransactionReport(returnMessage);
                transactionOperator.ReportTransaction(returnMessage);
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);//Action je ime metode
            }
            else
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }

            return returnMessage;
        }

        public string ZatvoriRacun(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("ZatvoriRacun"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        TransactionsOperator.transactions.Remove(r);
                        returnMessage = "Racun sa brojem: " + r.BrojRacuna.ToString() + " je zatvoren.\n";
                        transactionOperator.UpdateData();
                        Audit.TransactionReport(returnMessage);
                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
            }
            else 
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }
            
            return returnMessage;
        }
      
        public string ProveriStanje(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("ProveriStanje"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        returnMessage = "Trenutno stanje na racunu iznosi: " + r.Iznos.ToString() + " dinara.\n";
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }
               
                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);

            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }

            return returnMessage;
        }

        public string Uplata(Korisnik k, double suma)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("Uplata"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        r.Iznos += suma;

                        if (r.Iznos >= 0 && r.Blokiran == 1)
                            r.Blokiran = 0;
                        
                       
                        returnMessage = "Uplata na racun: " + r.BrojRacuna.ToString() + " u iznosi od: " + suma.ToString() + " dinara je izvrsena.\n";
                        r.PoslednjaTransakcija = DateTime.Now;
                        transactionOperator.UpdateData();
                        Audit.TransactionReport(returnMessage);

                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }

            return returnMessage;
        }

        public string Isplata(Korisnik k, double suma)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";

            if (Thread.CurrentPrincipal.IsInRole("Isplata"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        if (r.Blokiran == 1)
                        {
                            returnMessage = "Isplata nije moguca, racun je blokiran!\n";
                            Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);
                            return returnMessage;
                        }
                        if (r.Iznos - suma < 0)
                        {
                            if (Math.Abs(r.Iznos - suma) > r.DozvoljeniMinus)
                            {
                                returnMessage = "Isplata nije moguca, iznos je veci od dozvoljenog minusa!\n";
                                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);
                                return returnMessage;
                            }
                        }

                        r.Iznos -= suma;
                        returnMessage = "Isplata sa racuna: " + r.BrojRacuna.ToString() + " u iznosi od: " + suma.ToString() + " dinara je izvrsena.\n";
                        r.PoslednjaTransakcija = DateTime.Now;
                        transactionOperator.UpdateData();
                        Audit.TransactionReport(returnMessage);

                        transactionOperator.ReportTransaction(returnMessage);
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!";
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
            }
            else
            {
                returnMessage = "Nemate odgovarajuca prava pristupa!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);

                throw new FaultException("Nemate odgovarajuca prava pristupa!");
            }
            
            return returnMessage;
        }

        public string Opomena(Korisnik k)
        {
            MyPrincipal principal = Thread.CurrentPrincipal as MyPrincipal;
            string returnMessage = "";
            
            if (Thread.CurrentPrincipal.IsInRole("Opomena"))
            {
                foreach (Racun r in TransactionsOperator.transactions)
                {
                    if (r.Vlasnik.Username == k.Username)
                    {
                        if (r.Iznos < 0)
                        {
                            r.Blokiran = 1;
                            returnMessage = "Racun blokiran. Opomena!\n";
                            transactionOperator.UpdateData();
                            Audit.TransactionReport(returnMessage);

                            transactionOperator.ReportTransaction(returnMessage);
                            Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                            return returnMessage;
                        }

                        returnMessage = "Iznos na racunu korisnika nije u minusu!\n";
                        Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
                        return returnMessage;
                    }
                }

                returnMessage = "Korisnik nema racun!\n";
                Audit.AuthorizationSuccess(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action);
            }
            else
            {
                returnMessage = "Vi niste sluzbenik!\n";
                Audit.AuthorizationFailed(principal.Identity.Name, OperationContext.Current.IncomingMessageHeaders.Action, returnMessage);
                throw new FaultException("Vi niste sluzbenik!");
            }

            return returnMessage;
        }
    }
}
