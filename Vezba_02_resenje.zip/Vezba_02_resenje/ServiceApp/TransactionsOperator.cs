﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace ServiceApp
{
    public class TransactionsOperator
    {
        public static List<Racun> transactions = new List<Racun>();
        private int isLoaded = 0;

        public TransactionsOperator()
        {
            if (isLoaded == 0)
            {
                transactions = ReadData();

                isLoaded = 1;
            }
        }
        public List<Racun> ReadData()
        { 
            string serializationFile = "C:/Users/Jelena/Desktop/Vezba_02_resenje/DataBase.txt";
            try
            {
                using (Stream stream = File.Open(serializationFile, FileMode.Open))
                {
                    BinaryFormatter bformatter = new BinaryFormatter();

                    return (List<Racun>)bformatter.Deserialize(stream);
                }
            } 
            catch (Exception exc)
            {
                return new List<Racun>();
            }
        }

        public void UpdateData()
        {

            string serializationFile = "C:/Users/Jelena/Desktop/Vezba_02_resenje/DataBase.txt";
            //try
            //{
            using (Stream stream = File.Open(serializationFile, FileMode.Create))
            {
                BinaryFormatter bformatter = new BinaryFormatter();

                bformatter.Serialize(stream, transactions);
            }
            //}
            //catch (Exception exc)
            //{
            //    Console.WriteLine("Searilization failed with error " + exc.Message);
            //}
        }

        public void ReportTransaction(string newTransaction)
        {
            string serializationFile = "C:/Users/Jelena/Desktop/Vezba_02_resenje/TransactionReports.txt";

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(serializationFile, true))
            //using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\Public\TestFolder\WriteLines2.txt", true))
            {
                file.WriteLine(newTransaction);
            }
        }
    }
}
