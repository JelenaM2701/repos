﻿using Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ServiceApp
{
    class MyAuthorizationManager : ServiceAuthorizationManager
    {
        //kad god pozovem metodu u wcfservice ovo ce da se pozove pre toga
        protected override bool CheckAccessCore(OperationContext operationContext)
        {
            WindowsIdentity identity = operationContext.ServiceSecurityContext.WindowsIdentity;
            MyPrincipal principal = new MyPrincipal(identity);
            // return  principal.isInRole("a") to bi znacilo da mora svaki korisnik da ima permisiju 'a'
            // kako bi usao u izvrsavanje metode
            return true;
        }
    }
}
