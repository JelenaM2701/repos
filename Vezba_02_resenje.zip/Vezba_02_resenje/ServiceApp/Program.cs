﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Contracts;
using System.ServiceModel.Security;
using Manager;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceModel.Description;
using System.IdentityModel.Policy;
using System.Diagnostics;

namespace ServiceApp
{
	public class Program
	{
        
		static void Main(string[] args)
		{
            /// srvCertCN.SubjectName should be set to the service's username. .NET WindowsIdentity class provides information about Windows user running the given process
            string srvCertCN = Formatter.ParseName(WindowsIdentity.GetCurrent().Name);

            NetTcpBinding binding2 = new NetTcpBinding();
            binding2.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            string address2 = "net.tcp://localhost:10000/Receiver";
            ServiceHost host2 = new ServiceHost(typeof(WCFServiceCert));
            host2.AddServiceEndpoint(typeof(IWCFServiceCert), binding2, address2);

            ///PeerTrust - for development purposes only to temporarily disable the mechanism that checks the chain of trust for a certificate. 
            ///To do this, set the CertificateValidationMode property to PeerTrust (PeerOrChainTrust) - specifies that the certificate can be self-issued (peer trust) 
            ///To support that, the certificates created for the client and server in the personal certificates folder need to be copied in the Trusted people -> Certificates folder.
            ///host.Credentials.ClientCertificate.Authentication.CertificateValidationMode = X509CertificateValidationMode.PeerTrust;

            ///Custom validation mode enables creation of a custom validator - CustomCertificateValidator
            ///

            host2.Credentials.ClientCertificate.Authentication.CertificateValidationMode = X509CertificateValidationMode.Custom;
            host2.Credentials.ClientCertificate.Authentication.CustomCertificateValidator = new ServiceCertValidator();

            ///If CA doesn't have a CRL associated, WCF blocks every client because it cannot be validated
            host2.Credentials.ClientCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;

            ///Set appropriate service's certificate on the host. Use CertManager class to obtain the certificate based on the "srvCertCN"
            host2.Credentials.ServiceCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, srvCertCN);
            /// host.Credentials.ServiceCertificate.Certificate = CertManager.GetCertificateFromFile("WCFService.pfx");




            ServiceSecurityAuditBehavior newAudit2 = new ServiceSecurityAuditBehavior();
            newAudit2.AuditLogLocation = AuditLogLocation.Application;
            newAudit2.ServiceAuthorizationAuditLevel = AuditLevel.SuccessOrFailure;
            newAudit2.SuppressAuditFailure = true;

            host2.Description.Behaviors.Remove<ServiceSecurityAuditBehavior>();
            host2.Description.Behaviors.Add(newAudit2);


            try
            {
                host2.Open();
                Console.WriteLine("WCFService is started.\nPress <enter> to stop ...");

                
                NetTcpBinding binding = new NetTcpBinding();
                // windows mora zato sto sa certificate nece biti popunjen windowsidentity koji se koristi kasnije u myprincipal
                binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;
                
                string address = "net.tcp://localhost:10001/Receiver";
                ServiceHost host = new ServiceHost(typeof(WCFService));
                host.AddServiceEndpoint(typeof(IWCFContract), binding, address);
                
                //bzvz :)
                host.Description.Behaviors.Remove(typeof(ServiceDebugBehavior));
                host.Description.Behaviors.Add(new ServiceDebugBehavior() { IncludeExceptionDetailInFaults = true });


                //  dodaje se CheckAccesCore umesto onog predefinisanog koji vraca true
                host.Authorization.ServiceAuthorizationManager = new MyAuthorizationManager();
                host.Authorization.PrincipalPermissionMode = PrincipalPermissionMode.Custom;
               
                //RBAC - ROLE BASED ACCESS CONTROL je kada za grupe vezujemo permisije
                // i onda kada proveravamo permisiju prolazimo kroz sve grupe od korisnika i gledamo da li ima ta permisija u jednoj od grupa
                List<IAuthorizationPolicy> policies = new List<IAuthorizationPolicy>();
                policies.Add(new CustomAuthorizationPolicy());
                host.Authorization.ExternalAuthorizationPolicies = policies.AsReadOnly();


                //
                ServiceSecurityAuditBehavior newAudit = new ServiceSecurityAuditBehavior();
                newAudit.AuditLogLocation = AuditLogLocation.Application;
                newAudit.ServiceAuthorizationAuditLevel = AuditLevel.SuccessOrFailure;
                newAudit.SuppressAuditFailure = true;

                host.Description.Behaviors.Remove<ServiceSecurityAuditBehavior>();
                host.Description.Behaviors.Add(newAudit);
                //DO OVDE


                try
                {
                    host.Open();
                    Console.WriteLine("WCFService is started.\nPress <enter> to stop ...");
                    Console.ReadLine();
                }
                catch (Exception e)
                {
                    Console.WriteLine("[ERROR] {0}", e.Message);
                    Console.WriteLine("[StackTrace] {0}", e.StackTrace);
                }
                finally
                {
                    host.Close();
                }

                Console.ReadLine();
            }
            catch (Exception e)
            {
                Audit.AuthenticationFailed(srvCertCN);
                Console.WriteLine("[ERROR] {0}", e.Message);
                Console.WriteLine("[StackTrace] {0}", e.StackTrace);
            }
            finally
            {
                host2.Close();
            }




            
		}
	}
}
