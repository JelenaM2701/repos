﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Manager
{
    public class MyPrincipal:IPrincipal
    {
        //identitet korisnika koji se zakacio :D
        public IIdentity id;

        public IIdentity Identity
        {
            
            get
            {
                return id;
            }
        }
        // ovo redefinise ugradjenu isInRole metodu koja proverava da li je korisnik u grupi
        public bool IsInRole(string role)
        {
            
            // Mi hocemo da proverimo da li grupa u kojoj se nalazi korisnik ima odredjenu permisiju
            WindowsIdentity wi = id as WindowsIdentity; // kupis id sto je zakacen korisnik :D
           
            foreach (IdentityReference u in wi.Groups)
            {
                
                string toBeSearched = "\\";
                
                string current_group = (u.Translate(typeof(NTAccount)).ToString()).Substring((u.Translate(typeof(NTAccount)).ToString()).IndexOf(toBeSearched) + toBeSearched.Length);
                if (current_group == Roles.Sluzbenik)
                {
                    // Proveravamo da li grupa sluzbenik ima permisiju koja je prosledjena u funckiju iz WCF service-a
                    if (RolesConfig.Sluzbenik.Contains(role))
                    {
                        return true;
                    }
                }
                else if (current_group == Roles.Korisnik)
                {
                    if (RolesConfig.Korisnik.Contains(role))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public MyPrincipal()
        {

        }
        public MyPrincipal(IIdentity wi)
        {
            id = wi;
        }
    }
}
