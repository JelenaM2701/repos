﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Common;

namespace Contracts
{
	[ServiceContract]
	public interface IWCFContract
	{

		[OperationContract]
		void SendMessage(string message, byte[] sign);

        [OperationContract]
        string OtvoriRacun(Korisnik k);

        [OperationContract]
        string ZatvoriRacun(Korisnik k);

        [OperationContract]
        string ProveriStanje(Korisnik k);

        [OperationContract]
        string Uplata(Korisnik k, double suma);

        [OperationContract]
        string Isplata(Korisnik k, double suma);

        [OperationContract]
        string Opomena(Korisnik k);

    }
}
