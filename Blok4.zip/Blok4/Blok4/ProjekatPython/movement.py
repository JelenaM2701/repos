from PyQt5.QtCore import Qt, QRect, QTimer, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QPixmap, QIcon, QPainter, QFont
from PyQt5.QtWidgets import QLabel, QMainWindow

from key_notifier import KeyNotifier
from enemyone import EnemyOne
from enemytwo import EnemyTwo
from enemythree import EnemyThree

import threading
import time
import random

#u ovoj klasi se radi ceo UI interfejs

class Movement(QMainWindow):
   #signali
   #ovim definisemo signal pod nazivom "closed" koji nema argumenata
    closed = pyqtSignal()
	#score za desnog
    player1_text = pyqtSignal(str)
	#score za levog
    player2_text = pyqtSignal(str)
	#da nam sakrije random silu
    hide_Deus = pyqtSignal()
	#da ponovo postavi nasu silu na random mesto
    setVisible_Deus = pyqtSignal(int, int, int, int)
	#da se pojavljuje random
    geometry_Deus = pyqtSignal(int, int, int, int)

    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        self.parent = parent

		#brzina kretanja naseg aviona
        self.moveSpeed = 13
		
		#brojac metkova za nase aviona
        self.bulletCounter1 = 0
        self.bulletCounter2 = 0
		
		#za prijatelje i za neprijatelje, te liste se pune i prazne 
        self.bulletListP = []
        self.bulletListE = [] 
		#tu su protivnici, one njihove slicice
        self.enemies = []
		
		#brojac kako da nam se pojavljuju avioni, prvi talas, drugi talas, treci talas
        self.enemyCounter = 0
		
		#pozicija labele sa tom slikom
		#sev se bazira na labelama koje sadrze slike
		self.seaPos = 0
		
		#koliko je zivota ostalo igracima, ono sto stoji u coskovima
        self.lives_left_player1 = 3
        self.lives_left_player2 = 3
		
        self.player1_score = 0
        self.player2_score = 0
		
		#prvi talas 1 avion, 2. dva itd. 
        self.planeCounter = 1

		#za pravljenje srca, na svake 2 sekunde random sila, srce
        self.interval = 2

		#prelaz sa 6 na 7
        self.timer = QTimer(self)
        self.timer.setSingleShot(False)
		#na svakih 10ms nam azurira apsolutno sve
        self.timer.setInterval(10)
		#povezuje se na frame definiciju, u njoj e sve radi, najbitnija logika
        self.timer.timeout.connect(self.frame)
		
		#startuje na 10 ms
        self.timer.start(10)

		#pozivam signal i konektujem ga na metodu text_player1
		#izvrsavaju se u freajmu, da nismo stavili signale, onda bi u niti, doslo bi do preplitanja i puklo bi
        self.player1_text.connect(self.text_player1)
        self.player2_text.connect(self.text_player2)
        self.hide_Deus.connect(self.deus_hide)
        self.setVisible_Deus.connect(self.deus_SetVisible)
        self.geometry_Deus.connect(self.deus_Geometry)

		#pozicija prozora za igru
        self.setGeometry(450, 70, 1024, 900)
		#da se ne moze razvuci
        self.setMinimumSize(1024, 900)
        self.setMaximumSize(1024, 900)

        self.randomForce = QPixmap('images/srcko.png').scaled(50, 45)
        self.DeusExMachina = QLabel(self)

		#3,2,1 srce
        self.life3_player1 = QPixmap('images/life3_player1.png')
        self.life2_player1 = QPixmap('images/life2_player1.png')
        self.life1_player1 = QPixmap('images/life1_player1.png')
        self.label_player1 = QLabel(self)

        self.life3_player2 = QPixmap('images/life3_player2.png')
        self.life2_player2 = QPixmap('images/life2_player2.png')
        self.life1_player2 = QPixmap('images/life1_player2.png')
        self.label_player2 = QLabel(self)

        self.enemy1 = QPixmap('images/enemy1.png')
        self.enemy2 = QPixmap('images/enemy2.png')
        self.enemy3 = QPixmap('images/enemy3.png')

        self.pix1 = QPixmap('images/player1.png')
        self.pix2 = QPixmap('images/player2.png')
        self.label1 = QLabel(self)
        self.label2 = QLabel(self)

		#rezultat da bude boldovan i da se lepo vidi
		#velicina i font rezultata
        self.f = QFont("Gothic", 16)
        self.f.setBold(True)

		#inicijalizovali labele za rezultate
        self.score_player1 = QLabel(self)
        self.score_player2 = QLabel(self)
		#tako se primenjuje font na igrace
        self.score_player1.setFont(self.f)
        self.score_player2.setFont(self.f)

		
		
        self.seaTex = QPixmap("images/sea.png").scaled(70, 77)

		#kad se izgine, da se pojavi game over
        self.gameOver = QPixmap('images/gameOver.jpg').scaled(1024, 900)
        self.gameOverLabel = QLabel(self)

		
        self.__init_ui__()

        self.key_notifier = KeyNotifier()
        self.key_notifier.key_signal.connect(self.__update_position__)
        self.key_notifier.start()
		
#ovde u svaki label ucitava pixmap i postavlja je na neku poziciju na ekranu
#QPixmap je klasa za ucitavanje slika
    def __init_ui__(self):
        self.label1.setPixmap(self.pix1)
        self.label1.setGeometry(873, 760, 75, 60)

        self.label2.setPixmap(self.pix2)
        self.label2.setGeometry(55, 760, 75, 57)

        self.label_player1.setPixmap(self.life3_player1)
        self.label_player1.setGeometry(850, 835, 150, 33)

        self.label_player2.setPixmap(self.life3_player2)
        self.label_player2.setGeometry(30, 835, 150, 33)

        self.score_player1.setGeometry(874, 3, 200, 100)
        self.score_player1.setText(" 1UP\n {0}".format(self.player1_score))

        self.score_player2.setGeometry(24, 3, 200, 100)
        self.score_player2.setText(" 2UP\n {0}".format(self.player2_score))

        self.DeusExMachina.setPixmap(self.randomForce)
        self.DeusExMachina.setGeometry(random.randint(124, 900), random.randint(450, 859), 50, 45)

		#pozadinska nit, ona ce resavati tu nepredvidjenu silu
		#ovo se ne odnosi na frejm, radi se u pozadini, nezavisno od frejma
		#ako imamo ono odlaganje u ms, da ne bismo uspavljivali glavnu nit
		#ako je avion dodirne, dobija poene#ako ne, ona se samo prebaciu na drugo mesto
		#to je sve sto on radi
        self..0		= threading.Thread(target=self.justDoIt, args=())
		#pozadinska nit se zavrsava kad se zavrsi glavna nit
        #ako ne stavimo true, pozadinska ce se i dalje izvrsavati
        self.thread.daemon = True
        self.thread.start()

        self.setWindowTitle('1942')
        self.setWindowIcon(QIcon('images/icon.png'))
        self.show()

    @pyqtSlot(str)
    def text_player1(self, text):
        self.score_player1.setText(text)

    @pyqtSlot(str)
    def text_player2(self, text):
        self.score_player2.setText(text)

    @pyqtSlot()
    def deus_hide(self):
        self.DeusExMachina.hide()
        self.DeusExMachina.setVisible(0)

    @pyqtSlot(int, int, int, int)
    def deus_SetVisible(self, x, y, w, h):
        self.DeusExMachina.setVisible(1)
        self.DeusExMachina.setGeometry(x, y, w, h)

    @pyqtSlot(int, int, int, int)
    def deus_Geometry(self, x, y, w, h):
        self.DeusExMachina.setGeometry(x, y, w, h)

    def justDoIt(self):
	#pocinje da broji vreme
        self.startTime = time.time()
		
        while True:
            player1: QRect = self.label1.geometry()
            player1.setCoords(player1.x() + 30, player1.y(), player1.x() + 45, player1.y() + 60)
            player2: QRect = self.label2.geometry()
            player2.setCoords(player2.x() + 30, player2.y(), player2.x() + 45, player2.y() + 60)
            # self.startTime = time.time()
			#uzimamo pravougaonik te sile iako je u obliku srca
            randomForce: QRect = self.DeusExMachina.geometry()
			#da li ce nam se povecati ili sanjiti bodovi
			#ako je 0, uvecava za 100, 1 smanjuje za sto
            choice = random.randint(0, 1)

			#ukoliko prvi igrac dodje u dodir sa random silom i ako je ona vidjiva
			#sakrice se srce i bice mu vidljivost 0
			#u zavisnosti od toga, - ili + poeni
            if player1.intersects(randomForce):
                if self.DeusExMachina.isVisible() == True:
                    self.hide_Deus.emit()
                    if choice == 0:
                        self.player1_score += 100
                        self.player1_text.emit(" 1UP\n {0}".format(self.player1_score))
                    else:
                        self.player1_score -= 100
                        self.player1_text.emit(" 1UP\n {0}".format(self.player1_score))

                    time.sleep(self.interval)
                else:
				#{}
                    pass

            if player2.intersects(randomForce):
                if self.DeusExMachina.isVisible() == True:
                    self.hide_Deus.emit()
                    if choice == 0:
                        self.player2_score += 100
                        self.player2_text.emit(" 2UP\n {0}".format(self.player2_score))
                    else:
                        self.player2_score -= 100
                        self.player2_text.emit(" 2UP\n {0}".format(self.player2_score))

                    time.sleep(self.interval)
                else:
                    pass

					#124,900 od kog do kog dela ekrana
					#50,45 sirina i visina srca
					#gore postavljamo za sliku, a ovde za labelu
					#zamisli da slika ima 50 45, a labela 100 120...zamisli samo :D
					
					#ako je nevidjivo srce, postavimo je vidljivom i pozicioniramo na random poziciju
					#sa emit se poziva metoda preko signala
					#signal je setVisible_Deus
            if self.DeusExMachina.isVisible() == False:
                self.setVisible_Deus.emit(random.randint(124, 900), random.randint(450, 859), 50, 45)
                self.startTime = time.time()
            else:
			#ukoliko je vidljivo srce i niko je ne pokupi
			#elapsed time - pocetno vreme
			#time.time() je pocetno vreme
			#ako 3 sekunde niko nije pokupio srce, gubi se
                self.elapsedTime = time.time() - self.startTime
                if self.elapsedTime > 3:
                    self.hide_Deus.emit()
                #bez toga secka program, malo da se thread uspava
            time.sleep(0.01)

	#kad preitisnem, doda key u neku listu
    def keyPressEvent(self, event):
        self.key_notifier.add_key(event.key())
#kad ga pustim, izuzme se iz liste
    def keyReleaseEvent(self, event):
        self.key_notifier.rem_key(event.key())

		#rec1 instanca klase QRect (pravougaonik)
    def __update_position__(self, key):
        rec1: QRect = self.label1.geometry()
        rec2: QRect = self.label2.geometry()

		
        if key == Qt.Key_Right:
		#ako ode do kraja prozora, ne moze da ga predje koliko god se kretao
		#ako avion umre, nista se ne desava
            if rec1.x() + rec1.width() <= 1024:
                if self.label1.isVisible() == False:
                    pass
                else:
                    self.label1.setGeometry(rec1.x() + self.moveSpeed, rec1.y(), rec1.width(), rec1.height())
		#ako ode do kraja prozora, ne moze da ga predje koliko god se kretao
		#ako avion umre, nista se ne desava		
        elif key == Qt.Key_Down:
            if rec1.y() + rec1.height() <= 900:
                if self.label1.isVisible() == False:
                    pass
                else:
                    self.label1.setGeometry(rec1.x(), rec1.y() + self.moveSpeed, rec1.width(), rec1.height())
					#isto
        elif key == Qt.Key_Up:
            if rec1.y() > 1:
                if self.label1.isVisible() == False:
                    pass
                else:
                    self.label1.setGeometry(rec1.x(), rec1.y() - self.moveSpeed, rec1.width(), rec1.height())
					#isto
        elif key == Qt.Key_Left:
            if rec1.x() > 0:
                if self.label1.isVisible() == False:
                    pass
                else:
                    self.label1.setGeometry(rec1.x() - self.moveSpeed, rec1.y(), rec1.width(), rec1.height())
					#na L se puca
        elif key == Qt.Key_L:
            if self.label1.isVisible() == False:
                pass
            else:
                if self.bulletCounter1 == 0:
				#kod nas uvek puca istom brzinom, 20 ms#to se ucitava u labelu
				#setObjectName postavljamo da znamo kome ce dodati score..to je nas igrac i kad ubije neprijatelja, dobija poene
                    self.bulletCounter1 = 20
                    temp = QLabel(self)
                    temp.setObjectName(" 1")
					#pozicionira metak u centar aviona
					#4 po x, 10 po y, 7 sirina metka, 12 visina metka
					#dodajemo ga u listu, da bismo cuvali metke, a i da se automatski obrise kada se ispali
                    temp.setGeometry(rec1.x() + rec1.width() / 2 - 4, rec1.y() - 10, 7, 12)
                    temp.setPixmap(QPixmap('images/bullet1.png').scaled(7, 12))
                    temp.show()
                    self.bulletListP.append(temp)

					
        if key == Qt.Key_D:
            if rec2.x() + rec2.width() <= 1024:
                if self.label2.isVisible() == False:
                    pass
                else:
                    self.label2.setGeometry(rec2.x() + self.moveSpeed, rec2.y(), rec2.width(), rec2.height())
        elif key == Qt.Key_S:
            if rec2.y() + rec2.height() <= 900:
                if self.label2.isVisible() == False:
                    pass
                else:
                    self.label2.setGeometry(rec2.x(), rec2.y() + self.moveSpeed, rec2.width(), rec2.height())
        elif key == Qt.Key_W:
            if rec2.y() > 1:
                if self.label2.isVisible() == False:
                    pass
                else:
                    self.label2.setGeometry(rec2.x(), rec2.y() - self.moveSpeed, rec2.width(), rec2.height())
        elif key == Qt.Key_A:
            if rec2.x() > 0:
                if self.label2.isVisible() == False:
                    pass
                else:
                    self.label2.setGeometry(rec2.x() - self.moveSpeed, rec2.y(), rec2.width(), rec2.height())
        elif key == Qt.Key_R:
            if self.label2.isVisible() == False:
                pass
            else:
                if self.bulletCounter2 == 0:
                    self.bulletCounter2 = 20
                    temp = QLabel(self)
                    temp.setObjectName(" 2")
                    temp.setGeometry(rec2.x() + rec2.width() / 2 - 4, rec2.y() - 10, 7, 12)
                    temp.setPixmap(QPixmap('images/bullet1.png').scaled(7, 12))
                    temp.show()
                    self.bulletListP.append(temp)

		#esc, vratimo se na onaj prozor
        if key == Qt.Key_Escape:
            self.close()

    def closeEvent(self, event):
        self.key_notifier.die()
		#start da udje u igru, esc da izadje, sinhronizacija izmedju ta dva prozora preko signala
        self.closed.emit()
        event.accept()

		#automatski se poziva, definisam preko QPainter klase#svaki put ce iscrtavati pravougaonike koji ce prikazati more
		#redja pravougaonike sa slikom mora i stice se uticaj da se pomera
    def paintEvent(self, *args, **kwargs):
        p = QPainter(self)

        for i in range(0, 15):
            for j in range(-1, 12):
                p.drawPixmap(i * self.seaTex.width(), j * self.seaTex.height() + self.seaPos, self.seaTex)

				#glavna metoda, tu je glavna logika
    def frame(self):
        if self.bulletCounter1 > 0:
            self.bulletCounter1 -= 1

        if self.bulletCounter2 > 0:
            self.bulletCounter2 -= 1

		#brzina kretanja mora 	
        self.seaPos += 2
		#kad dodje slika do vrha prozora, onda ce da resetuje
        if self.seaPos > self.seaTex.height():
            self.seaPos = 0

		#nasi neprijatelji, kako dolae iz talasa u talas
		#na svaki talas, poveca se za jedan avion
        if len(self.enemies) == 0:
            for i in range(0, self.planeCounter): # random.randint(1, 1)):
                if self.enemyCounter == 0:
                    self.enemies.append(EnemyOne(self))
					#setujemo negde van ekrana i moveto mu kaze odakle koji dolazi, videces kako se pojavljuju avioni
					#kad se poredja 6, sledeci se stavlja u sledeci red
                    self.enemies[i].setPosition(i % 6 * 150 - 200 * i % 6, 100)
                    self.enemies[i].moveTo(100 + i % 6 * 150, 100 + i // 6 * 100)
                elif self.enemyCounter == 1:
                    self.enemies.append(EnemyTwo(self))
                    self.enemies[i].setPosition(i % 6 * 150 + 900, -100)
                    self.enemies[i].moveTo(100 + i % 6 * 150, 100 + i // 6 * 100)
                elif self.enemyCounter == 2:
                    self.enemies.append(EnemyThree(self))
                    self.enemies[i].setPosition(i % 6 * 150 + 100, -100)
                    self.enemies[i].moveTo(100 + i % 6 * 150, 100 + i // 6 * 100)

            self.enemyCounter += 1
            if self.enemyCounter == 3:
                self.enemyCounter = 0
                self.planeCounter += 1

		#pomocu fire se krece metak, inace bi stajao
		#na svakih 10 ms se azurira paljba metkova
		#u slucaju neprijatelja na svakih 30-150 
        for enemy1 in self.enemies:
            enemy1.update()
            enemy1.fire()

			
		#mi kad ispaljujemo
		#namestamo u geometriju, -3 da ispucava na gore
		# -10 = probija gornju ivicu
			
        for bullet in self.bulletListP:
            rec: QRect = bullet.geometry()
            bullet.setGeometry(rec.x(), rec.y() - 3, rec.width(), rec.height())
            if rec.y() < -10:
			#clear-ujemo metak, samo nestane i izbacimo ga iz liste
                bullet.clear()
                self.bulletListP.remove(bullet)

				#ako nas metak dodirne neprijateljsku labelu, taj metak clear-ujemo 
            for enemy in self.enemies:
                if rec.intersects(enemy.label.geometry()):
                    bullet.clear()
					#ako nas metak pogodi dve labele, dodje do exception-a, ovo ga sprecava, da mozemo da pogodimo oba odjednom
                    if bullet in self.bulletListP:
                        self.bulletListP.remove(bullet)
						#ukoliko mi pogodimo neprijatelja, njihova labela se clear-uje
						#onda ga uklonimo iz liste eprijatelja
                    if enemy.hit():
                        enemy.label.clear()
                        self.enemies.remove(enemy)
						#ukoliko je igrac 1 pogodio, njemu ce se pisati rezultati u zavisnosti od toga da li je ubio prvog, drugog ili treceg neprijatelja
                        if bullet.objectName() == " 1":
                            if isinstance(enemy, EnemyOne):
                                self.player1_score += 10
                            elif isinstance(enemy, EnemyTwo):
                                self.player1_score += 20
                            elif isinstance(enemy, EnemyThree):
                                self.player1_score += 30

								#za azuriranje rezultata
                            self.score_player1.setText(" 1UP\n {0}".format(self.player1_score))
                        else:
						#ovde to isto samo za neprijatelja 2
                            if isinstance(enemy, EnemyOne):
                                self.player2_score += 10
                            elif isinstance(enemy, EnemyTwo):
                                self.player2_score += 20
                            elif isinstance(enemy, EnemyThree):
                                self.player2_score += 30

                            self.score_player2.setText(" 2UP\n {0}".format(self.player2_score))

                    break

					#za metkove u listi neprijatelja
					#uzimamo za player-a 1 i 2
					#da ga ne ubije ako dodirne krila, nego samo da prodje kroz njega
        for bullet in self.bulletListE:
            rec: QRect = bullet.geometry()
            player1: QRect = self.label1.geometry()
            player1.setCoords(player1.x() + 30, player1.y(), player1.x() + 45, player1.y() + 60)
            player2: QRect = self.label2.geometry()
            player2.setCoords(player2.x() + 30, player2.y(), player2.x() + 45, player2.y() + 60)
			#+3, jer puca na dole
            bullet.setGeometry(rec.x(), rec.y() + 3, rec.width(), rec.height())
			#910 donja granica ekrana, ako ode dole, brisi ga
            if rec.y() > 910:
                bullet.clear()
                self.bulletListE.remove(bullet)

				3ako je vidljiva, ziv je i ako njihov mtak dodirne sredisnji deo naseg igraca
				#smanji brojac zivota -1
				#postavi sliku sa 3 srca, na 2 srca, izgubio zivot
				#ako spada na nulu, onda se ta labela nacisto brise, ne vidi se vise
				#SetVisible(0), kao da sam stavila false
				#zivoti: 3,2,1 i nestaje
            if self.label1.isVisible() == True:
                if rec.intersects(player1):
                    bullet.clear()
                    self.bulletListE.remove(bullet)

                    if self.lives_left_player1 == 3:
                        self.lives_left_player1 -= 1
                        self.label_player1.clear()
                        self.label_player1.setPixmap(self.life2_player1)
                        self.label_player1.setGeometry(850, 835, 84, 33)
                    elif self.lives_left_player1 == 2:
                        self.lives_left_player1 -= 1
                        self.label_player1.clear()
                        self.label_player1.setPixmap(self.life1_player1)
                        self.label_player1.setGeometry(850, 835, 37, 33)
                    else:
                        self.lives_left_player1 -= 1
                        self.label_player1.clear()
                        if self.lives_left_player1 == 0:
                            self.label1.setVisible(0)

			#sve to isto samo za drugog igraca
            if self.label2.isVisible() == True:
                if rec.intersects(player2):
                    bullet.clear()
                    self.bulletListE.remove(bullet)

                    if self.lives_left_player2 == 3:
                        self.lives_left_player2 -= 1
                        self.label_player2.clear()
                        self.label_player2.setPixmap(self.life2_player2)
                        self.label_player2.setGeometry(30, 835, 84, 33)
                    elif self.lives_left_player2 == 2:
                        self.lives_left_player2 -= 1
                        self.label_player2.clear()
                        self.label_player2.setPixmap(self.life1_player2)
                        self.label_player2.setGeometry(30, 835, 37, 33)
                    else:
                        self.lives_left_player2 -= 1
                        self.label_player2.clear()
                        if self.lives_left_player2 == 0:
                            self.label2.setVisible(0)

							#ukoliko oba igraca nestanu, stopiramo tajmer sto smo stavili na 10ms (koji je bio za pokretanje cele frame f-je u kojoj se sve radilo)
							#postavimo GAME OVER
							#gledamo ko ima veci rezultat
							#"a" - append
							#upisuje se u txt datoteku 
							#ukoliko su jednaki, upise se rezultat oba
        if self.label1.isVisible() == False and self.label2.isVisible() == False:
            self.timer.stop()
            self.gameOverLabel.setPixmap(self.gameOver)
            self.gameOverLabel.setGeometry(0, 0, 1024, 900)
            if self.player1_score > self.player2_score:
                text_file = open("player1.txt", "a")
                text_file.write("\nPlayer1 score: %i\n-------------------------" % self.player1_score)
                text_file.close()
            elif self.player1_score < self.player2_score:
                text_file = open("player2.txt", "a")
                text_file.write("\nPlayer2 score: %i\n-------------------------" % self.player2_score)
                text_file.close()
            else:
                text_file = open("playerTied.txt", "a")
                text_file.write("\nPlayer1 score: %i\nPlayer2 score: %i\n---------------------------" % (self.player1_score, self.player2_score))
                text_file.close()
#automatski radi refresh na onih 10ms, svaku akciju da refresh-uje, to je fora kod tajmera
        self.update()