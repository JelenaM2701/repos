from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtWidgets import QMainWindow, QLabel, QPushButton
from movement import Movement

*** to je za pocetnu sliku
*** gde ce sta da stoji

class Menu(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)

		
        self.logo = QPixmap('images/logo.png')
        self.label = QLabel(self)
		
		*** ucitava se slika, smesta se u labelu i u gemoetriji se podesava
		*** koordinate
		*** sirina i visina
		
		self.label.setPixmap(self.logo)
        self.label.setGeometry(0, 0, 800, 720)
        self.setGeometry(550, 150, 800, 720)
		
        self.resize(self.logo.width(), self.logo.height())	

         *** ako se postave min i max na isto, prozor se ne moze siriti tj. resize-ovati :D 

		
        self.setMinimumSize(self.logo.width(), self.logo.height())
        self.setMaximumSize(self.logo.width(), self.logo.height())
		
		
        self.setWindowTitle('1942')
		
		*** da se pokaze ikonica aviona
		
        self.setWindowIcon(QIcon('images/icon.png'))

		*** na start game dugme se poziva game window
		
        buttonPlay = QPushButton('START GAME', self)
        buttonPlay.clicked.connect(self.gamewindow)
		
		
        buttonPlay.resize(320, 40)
        buttonPlay.move(40, 320)

        buttonExit = QPushButton('EXIT', self)
        buttonExit.clicked.connect(self.exit)
        buttonExit.resize(320, 40)
        buttonExit.move(440, 320)

    def gamewindow(self):
        self.game = Movement(self)
		
		*** kad klikens dugme esc on se zatvori, ovaj se sakrije za to vreme ovako se prikaze
		*** prikaze se kada pokrenemo glavni nas, on se sakrije
        self.game.closed.connect(self.show)
        self.game.show()
        self.hide()

    def exit(self):
        self.close()
