from movement import *
import random

# health su zivoti
# ponasa se kao apstraktnaklasa

class Enemy:
    def __init__(self, mainWindow):
        self.health = 0
        self.width = 0
        self.height = 0
        self.x = 0
        self.y = 0
		# zeljena pozicija na koju ce se pomeriti, sa jede na drugu tacku, kad se pomeraju neprijateljski avioni
        self.targetx = 0
        self.targety = 0
		#brojac metkova i kojom brzinom ce se kretati
        self.bulletCounter = 0
        self.speed = 0
        self.isMoving = False
		
		#zato sto ce se ovo izvrsavati na nasem glavnom prozoru
		#posto ova klasa nema svoj prozor, veze se na prozor glavne klase (mainwindow)
		# seft.nesto je globalna promenljiva
		
        self.label = QLabel(mainWindow)
        self.label.show()
        self.mainWindow = mainWindow

		
		#postavlja poziciju neprijatelja
		#kod funkcija je prvi parametar uvek self
		
    def setPosition(self, x, y):
        self.x = x
        self.y = y
        self.label.setGeometry(x, y, self.width, self.height)

		# da gubimo zivot kada nas napadne neprijateljski avion
		# return -> aktivirace se kad nasi igraci dobiju 0, imaju 3 inace
		
    def hit(self):
        self.health -= 1
        return self.health == 0

		# pomeri se na drugu poziciju, sa desne strane se prebaci na levu
		
    def moveTo(self, x, y):
        self.targetx = x
        self.targety = y
        self.isMoving = True

		# y raste na dole
		
		
    def update(self):
        if self.isMoving:
		
		# kad dodje na zeljenu poziciju, prestaje da se mrda
		
            if self.x == self.targetx and self.y == self.targety:
                self.isMoving = False
				
	    # vidim gde mi se nalazi i gde treba da dodje i onda dodajem brzinu dok ne stigne dotle
		
            else:
                if self.targetx > self.x:
                    if abs(self.targetx - self.x) > self.speed:
                        self.x += self.speed
                    else:
                        self.x += self.targetx - self.x
                else:
                    if abs(self.targetx - self.x) > self.speed:
                        self.x -= self.speed
                    else:
                        self.x += self.targetx - self.x

                if self.targety > self.y:
                    if abs(self.targety - self.y) > self.speed:
                        self.y += self.speed
                    else:
                        self.y += self.targety - self.y
                else:
                    if abs(self.targety - self.y) > self.speed:
                        self.y -= self.speed
                    else:
                        self.y += self.targety - self.y
						
						
				# update na tu poziciju, da postavja tako iz frame u frame
				# prima koordinate i dimenzije neprijateljskog aviona 

                self.label.setGeometry(self.x, self.y, self.width, self.height)

				 
    def fire(self):
        if self.bulletCounter > 0:
            self.bulletCounter -= 1

        if self.bulletCounter == 0:
		#interval u kome ce ispaljivati metkove..ili na 30ms ili na 150ms, toliko frekventno da kuca
		# na svakih 10 ms se prazni, sto se bas ne vidi u kodu
		
            self.bulletCounter = random.randint(30, 150) # 200
			#labela se vezuje za prozor u kome se nalaze neprijatelji
            temp = QLabel(self.mainWindow)
            temp.setObjectName(" 3")
            rect = self.label.geometry()
			#geometry uzme x i y koordinatu labele
			#pozicioniramo metak da puca iz sredine, odakle ce da krece u odnosu na neprijateljski avion
            temp.setGeometry(rect.x() + rect.width() / 2 - 3, rect.y() + 69, 7, 12)
            temp.setPixmap(QPixmap('images/bullet2.png').scaled(7, 12))
            temp.show()
			#imamo u movement dve liste, u jednoj se skladiste prijateljski avioni, u drugoj neprijateljski, lista sluzi da imamo evidenciju
			#kako kog ubijemo, izbrise se iz liste da se ne puni memorija
            self.mainWindow.bulletListE.append(temp)
