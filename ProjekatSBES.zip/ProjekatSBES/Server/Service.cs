﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace Server
{

    public class Service : IService
    {

        Dictionary<string, Racun> racuni = new Dictionary<string, Racun>();


        public void Isplata(string korisnik, double isplata)
        {
            Racun r = racuni[korisnik];
            double ret = 0;

            if (r.Blokiran)
            {
                Console.WriteLine("Racun je blokiran. Isplata nije moguca. ");
            }
            else
            {
                if(isplata > (r.Iznos + r.DozvoljeniMinus))
                {
                    Console.WriteLine("Isplata nije moguca. ");
                }
                else
                {
                    ret = r.Iznos - isplata;
                }
            }
            Console.WriteLine("Iznos nakon isplate: {0} ", ret);
           

        }

        public void Opomena(string korisnik)
        {
            Racun r = racuni[korisnik];

            if(r.Iznos <  ((-1) * r.DozvoljeniMinus))
            {
                r.Blokiran = true;
                Console.WriteLine("U minusu ste. Vas racun je blokiran. ");
            }
        }

        public void OtvoriRacun(string korisnik)
        {
            if (!racuni.ContainsKey(korisnik))
            {
                Racun r = new Racun();
                racuni.Add(korisnik, r);
            }
            else
            {
                Console.WriteLine("Korisnik {0} vec ima otvoren racun. ", korisnik);
            }
        }

        public void ProveriStanje(string korisnik)
        {
            Racun r = racuni[korisnik];

            Console.WriteLine("Iznos na racunu je: {0} ", r.Iznos);
        }

        public void Uplata(string korisnik, double uplata)
        {
            Racun r = racuni[korisnik];

            double ret = 0;
                 
            if(r.Iznos >= 0)
            {
                ret = r.Iznos + uplata;
            }

            if(r.Iznos < 0 &&  (r.Iznos + uplata) >= 0)
            {
                if(r.Blokiran)
                {
                    r.Blokiran = false;
                    ret = r.Iznos + uplata;
                }
            }
            Console.WriteLine("Iznos nakon uplate: {0} ", ret);
            
        }

        public void ZatvoriRacun(string korisnik)
        {
            if (racuni.ContainsKey(korisnik))
            {
                racuni.Remove(korisnik);
            }
            else
            {
                Console.WriteLine("Korisnik {0} nema otvoren racun. ", korisnik);
            }
        }
    }
}
