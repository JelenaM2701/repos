﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace Common
{
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        void OtvoriRacun(string korisnik);

        [OperationContract]
        void ZatvoriRacun(string korisnik);

        [OperationContract]
        void ProveriStanje(string korisnik);

        [OperationContract]
        void Uplata(string korisnik, double uplata);

        [OperationContract]
        void Isplata(string korisnik, double isplata);

        [OperationContract]
        void Opomena(string korisnik);


    }
}
