﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Common
{
    [DataContract]
    public class Racun
    {
        long _broj;
        double _iznos;
        double _dozvoljeniMinus;
        bool _blokiran;
        DateTime _poslednjaTransakcija;
        string _info;  //informacija kom korisniku pripada

        public Racun() { }
        public Racun(long broj, double iznos, double dozvoljeniMinus, bool blokiran, DateTime poslednjaTransakcija, string info)
        {
            _broj = broj;
            _iznos = iznos;
            _dozvoljeniMinus = dozvoljeniMinus;
            _blokiran = blokiran;
            _poslednjaTransakcija = poslednjaTransakcija;
            _info = info;
        }

        [DataMember]
        public long Broj { get => _broj; set => _broj = value; }

        [DataMember]
        public double Iznos { get => _iznos; set => _iznos = value; }

        [DataMember]
        public double DozvoljeniMinus { get => _dozvoljeniMinus; set => _dozvoljeniMinus = value; }

        [DataMember]
        public bool Blokiran { get => _blokiran; set => _blokiran = value; }

        [DataMember]
        public DateTime PoslednjaTransakcija { get => _poslednjaTransakcija; set => _poslednjaTransakcija = value; }

        [DataMember]
        public string Info { get => _info; set => _info = value; }
    }

}
